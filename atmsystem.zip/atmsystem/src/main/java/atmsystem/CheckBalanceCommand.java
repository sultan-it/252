package atmsystem;

public class CheckBalanceCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;
    private ResultHandler resultHandler;

    public CheckBalanceCommand(ATMOperationsFacade facade,
            String accountId, ResultHandler resultHandler) {
        this.facade = facade;
        this.accountId = accountId;
        this.resultHandler = resultHandler;
    }

    @Override
    public void execute() {
        double balance = facade.checkBalance(accountId);
        resultHandler.handleResult("Your balance is: $" + balance);
    }
}
