package atmsystem;

public interface ResultHandler {

    void handleResult(String message);
}
