package atmsystem;

public class ATMController implements ResultHandler {

    private ATMInterface atmView;
    private ATMOperationsFacade atmOperations;
    private volatile boolean isAuthenticated = false;
    private String currentAccountId;  

    public ATMController(ATMInterface atmView, ATMOperationsFacade atmOperations) {
        this.atmView = atmView;
        this.atmOperations = atmOperations;
    }

    @Override
    public void handleResult(String message) {
        if ("Authenticated successfully.".equals(message)) {
            isAuthenticated = true;
            currentAccountId = atmOperations.getCurrentAccountId(); 
        } else if ("Authentication failed.".equals(message)) {
            isAuthenticated = false;
        }
        atmView.displayMessage(message);
    }

    public void startSession() {
        if (!ATMSession.getInstance().isActive()) {
            ATMSession.getInstance().startSession();
            handleResult("ATM session started.");
        }
    }

    public void endSession() {
        if (ATMSession.getInstance().isActive()) {
            ATMSession.getInstance().endSession();
            handleResult("Session ended.");
        }
    }

    public boolean isSessionActive() {
        return ATMSession.getInstance().isActive();
    }

    public void authenticateUser(String cardNumber, String pin) {
        isAuthenticated = false; 
        Command authCommand = new AuthenticateCommand(atmOperations, cardNumber, pin, this);
        authCommand.execute();
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void checkBalance() {
        if (currentAccountId != null) {
            Command checkBalanceCommand = new CheckBalanceCommand(atmOperations, currentAccountId, this);
            checkBalanceCommand.execute();
        }
    }

    public void withdrawMoney(double amount) {
        if (currentAccountId != null) {
            Command withdrawCommand = new WithdrawCommand(atmOperations, currentAccountId, amount, this);
            withdrawCommand.execute();
        }
    }

    public void depositMoney(double amount) {
        if (currentAccountId != null) {
            Command depositCommand = new DepositCommand(atmOperations, currentAccountId, amount, this);
            depositCommand.execute();
        }
    }

    public void transferMoney(String toAccountId, double amount) {
        if (currentAccountId != null) {
            Command transferCommand = new TransferCommand(atmOperations, currentAccountId, toAccountId, amount, this);
            transferCommand.execute();
        }
    }
}
