package atmsystem;

public class WithdrawCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;
    private double amount;
    private ResultHandler resultHandler;

    public WithdrawCommand(ATMOperationsFacade facade, 
            String accountId, double amount, ResultHandler resultHandler) {
        this.facade = facade;
        this.accountId = accountId;
        this.amount = amount;
        this.resultHandler = resultHandler;
    }

    @Override
    public void execute() {
        boolean success = facade.withdrawMoney(accountId, amount);
        resultHandler.handleResult(success ? 
                "Withdrawal successful." : "Insufficient funds.");
    }
}
