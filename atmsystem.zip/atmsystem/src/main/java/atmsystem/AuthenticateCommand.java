package atmsystem;

public class AuthenticateCommand implements Command {

    private ATMOperationsFacade facade;
    private String cardNumber;
    private String pin;
    private ResultHandler resultHandler;

    public AuthenticateCommand(ATMOperationsFacade facade, String cardNumber,
            String pin, ResultHandler resultHandler) {
        this.facade = facade;
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.resultHandler = resultHandler;
    }

    @Override
    public void execute() {
        boolean isAuthenticated = facade.authenticateUser(cardNumber, pin);
        resultHandler.handleResult(isAuthenticated ? "Authenticated successfully." : "Authentication failed.");
    }
}
