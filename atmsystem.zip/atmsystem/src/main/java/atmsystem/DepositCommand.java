package atmsystem;

public class DepositCommand implements Command {

    private ATMOperationsFacade facade;
    private String accountId;
    private double amount;
    private ResultHandler resultHandler;

    public DepositCommand(ATMOperationsFacade facade, 
            String accountId, double amount, ResultHandler resultHandler) {
        this.facade = facade;
        this.accountId = accountId;
        this.amount = amount;
        this.resultHandler = resultHandler;
    }

    @Override
    public void execute() {
        boolean success = facade.depositMoney(accountId, amount);
        resultHandler.handleResult(success ? "Deposit successful." : "Deposit failed.");
    }
}
