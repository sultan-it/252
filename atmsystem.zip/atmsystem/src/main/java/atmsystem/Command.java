package atmsystem;

public interface Command {

    void execute();
}
