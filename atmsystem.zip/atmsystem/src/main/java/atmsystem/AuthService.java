package atmsystem;

class AuthService {

    private AccountService accountService;
    private AccountModel currentAccount;

    public AuthService(AccountService accountService) {
        this.accountService = accountService;
    }

    public boolean authenticate(String cardNumber, String pin) {
        AccountModel account = accountService.getAccountByCard(cardNumber);
        if (account != null && account.getPin().equals(pin)) {
            currentAccount = account;
            return true;
        }
        return false;
    }

    public void logout() {
        currentAccount = null;
    }

    public AccountModel getCurrentAccount() {
        return currentAccount;
    }
}
