package atmsystem;

public class TransferCommand implements Command {

    private ATMOperationsFacade facade;
    private String fromAccountId;
    private String toAccountId;
    private double amount;
    private ResultHandler resultHandler;

    public TransferCommand(ATMOperationsFacade facade,
            String fromAccountId, String toAccountId,
            double amount, ResultHandler resultHandler) {
        this.facade = facade;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.amount = amount;
        this.resultHandler = resultHandler;
    }

    @Override
    public void execute() {
        boolean success = facade.transferMoney(fromAccountId, toAccountId, amount);
        resultHandler.handleResult(success ? "Transfer successful." : "Transfer failed.");
    }
}
