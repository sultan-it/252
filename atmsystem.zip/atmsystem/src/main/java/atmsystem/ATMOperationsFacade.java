package atmsystem;

public class ATMOperationsFacade {

    private AuthService authService;
    private TransactionService transactionService;
    private AccountService accountService;

    public ATMOperationsFacade(AuthService authService,
            TransactionService transactionService, AccountService accountService) 
    {
        this.authService = authService;
        this.transactionService = transactionService;
        this.accountService = accountService;
    }

    public boolean authenticateUser(String cardNumber, String pin) {
        return authService.authenticate(cardNumber, pin);
    }

    public String getCurrentAccountId() {
        AccountModel currentAccount = authService.getCurrentAccount();
        return currentAccount != null ? currentAccount.getId() : null;
    }

    public double checkBalance(String accountId) {
        AccountModel account = accountService.getAccount(accountId);
        return account != null ? account.getBalance() : -1;
    }

    public boolean withdrawMoney(String accountId, double amount) {
        return transactionService.withdraw(accountId, amount);
    }

    public boolean depositMoney(String accountId, double amount) {
        return transactionService.deposit(accountId, amount);
    }

    public boolean transferMoney(String fromAccountId, String toAccountId, double amount) {
        return transactionService.transfer(fromAccountId, toAccountId, amount);
    }

}
