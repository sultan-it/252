package atmsystem;

import java.util.HashMap;
import java.util.Map;
import java.io.*;

class AccountService {

    private Map<String, AccountModel> accounts;
    private String filePath;

    public AccountService(String filePath) {
        this.filePath = filePath;
        this.accounts = loadAccounts(filePath);
    }

    private Map<String, AccountModel> loadAccounts(String filePath) {
        Map<String, AccountModel> loadedAccounts = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            
            String line = reader.readLine();  // skips the first line of the file
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    try {
                        String id = parts[0];
                        String cardNumber = parts[1];
                        String pin = parts[2];
                        double balance = Double.parseDouble(parts[3]);
                        loadedAccounts.put(cardNumber, new AccountModel(id, cardNumber, pin, balance));
                    } catch (NumberFormatException e) {
                        System.err.println("Error parsing balance for line: " + line);
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return loadedAccounts;
    }

    public AccountModel getAccount(String accountId) {
        return accounts.values().stream()
                .filter(account -> account.getId().equals(accountId))
                .findFirst()
                .orElse(null);
    }

    public AccountModel getAccountByCard(String cardNumber) {
        return accounts.get(cardNumber); 
    }

    public void saveAccounts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("DemoAccounts.csv"))) {
            writer.write("ID,CardNumber,PIN,Balance\n");
            for (AccountModel account : accounts.values()) {
                writer.write(account.getId() + "," + account.getCardNumber() + "," + 
                        account.getPin() + "," + account.getBalance() + "\n");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
