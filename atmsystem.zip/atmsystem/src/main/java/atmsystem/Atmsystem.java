package atmsystem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Atmsystem {

    public static void main(String[] args) {
        String filename = "DemoAccounts.csv";
        File file = new File(filename);

        // Check if the file already exists
        if (!file.exists()) {
            try {
                generateDemoAccounts(filename);
            } catch (IOException e) {
                System.out.println("Failed to create demo accounts: " + e.getMessage());
                return;
            }
        }

        try (Scanner scanner = new Scanner(System.in)) {
            AccountService accountService = new AccountService("DemoAccounts.csv");
            AuthService authService = new AuthService(accountService);
            TransactionService transactionService = new TransactionService(accountService);
            ATMInterface atmInterface = new ATMInterface();
            ATMOperationsFacade atmOperationsFacade = new ATMOperationsFacade(authService, transactionService, accountService);
            ATMController atmController = new ATMController(atmInterface, atmOperationsFacade);

            System.out.println("Enter card number:");
            String cardNumber = scanner.nextLine();
            System.out.println("Enter PIN:");
            String pin = scanner.nextLine();

            // Authenticate and then enter main operation loop
            atmController.authenticateUser(cardNumber, pin);

            // Use a simple delay loop or event/wait mechanism here to wait for authentication to complete
            while (!atmController.isAuthenticated()) {
                try {
                    Thread.sleep(100); // Wait 100 ms then check again
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("Failed to wait for authentication to complete.");
                    return;
                }
            }

            // Start session if authenticated
            if (atmController.isAuthenticated()) {
                atmController.startSession();
                while (atmController.isSessionActive()) {
                    System.out.println("Select operation: 1-Check Balance, 2-Deposit, 3-Withdraw, 4-Transfer, 5-Logout");
                    int operation = scanner.nextInt();
                    switch (operation) {
                        case 1:
                            atmController.checkBalance();
                            break;
                        case 2:
                            System.out.println("Enter amount to deposit:");
                            double depositAmount = scanner.nextDouble();
                            atmController.depositMoney(depositAmount);
                            break;
                        case 3:
                            System.out.println("Enter amount to withdraw:");
                            double withdrawAmount = scanner.nextDouble();
                            atmController.withdrawMoney(withdrawAmount);
                            break;
                        case 4:
                            System.out.println("Enter target account ID:");
                            String targetAccountId = scanner.next();
                            System.out.println("Enter amount to transfer:");
                            double transferAmount = scanner.nextDouble();
                            atmController.transferMoney(targetAccountId, transferAmount);
                            break;
                        case 5:
                            atmController.endSession();
                            break;
                        default:
                            System.out.println("Invalid operation.");
                    }
                }
            } else {
                System.out.println("Authentication failed.");
            }
        }
    }

    private static void generateDemoAccounts(String filename) throws IOException {
        String[] accounts = {
            "ID,CardNumber,PIN,Balance",
            "1,123456,1234,1000.00",
            "2,234567,2345,1500.00",
            "3,345678,3456,2000.00",
            "4,456789,4567,2500.00",
            "5,567890,5678,3000.00",
            "6,678901,6789,3500.00",
            "7,789012,7890,4000.00",
            "8,890123,8901,4500.00",
            "9,901234,9012,5000.00",
            "10,012345,0123,5500.00"
        };
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (String account : accounts) {
                writer.println(account);
            }
        }
    }
}
