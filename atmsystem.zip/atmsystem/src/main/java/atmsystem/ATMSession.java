package atmsystem;

public class ATMSession {

    private static ATMSession instance = new ATMSession();
    private boolean active = false;

    private ATMSession() {
    }

    public static ATMSession getInstance() {
        return instance;
    }

    public boolean isActive() {
        return active;
    }

    public void startSession() {
        if (!active) {
            active = true;
        }
    }

    public void endSession() {
        if (active) {
            active = false;
        }
    }
}
