package atmsystem;

public class ATMInterface {

    public void displayMessage(String message) {
        System.out.println(message);
    }
}
